#ifndef ASPELL
#define ASPELL


#include <string>
#include <iostream>

class ATarget;

class ASpell
{
	private:
		std::string _name;
		std::string _effects;
		


	public:
		ASpell(std::string name, std::string effects);
		virtual ~ASpell();

		virtual ASpell *clone() const = 0; 


		std::string getName() const;
		std::string getEffects() const;
		void setEffects(std::string effects);
		void launch(const ATarget& target) const;

};


#endif