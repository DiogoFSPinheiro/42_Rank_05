#ifndef WARLOCK
#define WARLOCK

#include <string>
#include <iostream>
#include <map>

#include "ASpell.hpp"
#include "ATarget.hpp"

class Warlock
{
	private:
		std::string _name;
		std::string _title; 
		std::map<std::string ,ASpell* > _spells;


	public:
		Warlock(std::string name, std::string title);
		~Warlock();


		std::string getName() const;
		std::string getTitle() const;
		void setTitle(std::string title);
		void introduce() const;
		void learnSpell(ASpell* spell);
		void forgetSpell(std::string spell);
		void launchSpell(std::string spell, ATarget& target);
};


#endif