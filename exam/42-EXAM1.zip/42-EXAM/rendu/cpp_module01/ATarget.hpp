#ifndef ATARGET
#define ATARGET


#include <string>
#include <iostream>

class ASpell;

class ATarget
{
	private:
		std::string _type;


	public:
		ATarget(std::string type);
		virtual ~ATarget();

		virtual ATarget *clone() const = 0; 

		std::string getType() const;
		void getHitBySpell(const ASpell& spell) const;


};


#endif