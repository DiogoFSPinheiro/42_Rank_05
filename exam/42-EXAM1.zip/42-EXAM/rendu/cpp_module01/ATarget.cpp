

#include "ATarget.hpp"
#include "ASpell.hpp"

std::string ATarget::getType() const
{
	return this->_type;
}

void ATarget::getHitBySpell(const ASpell& spell) const
{
	std::cout << _type << " has been " << spell.getEffects() << "!" << std::endl;
}

ATarget::ATarget(std::string type) :_type(type)
{
}

ATarget::~ATarget()
{
}