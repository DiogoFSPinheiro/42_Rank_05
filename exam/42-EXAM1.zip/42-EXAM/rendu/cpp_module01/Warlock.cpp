

#include "Warlock.hpp"
#include "ATarget.hpp"
#include <cstddef>

std::string Warlock::getName() const
{
	return this->_name;
}

std::string Warlock::getTitle() const
{
	return this->_title;
}

void Warlock::setTitle(std::string title) 
{
	this->_title = title;
}

void Warlock::learnSpell(ASpell* spell)
{
	if (!spell)
		return;
	
	std::map<std::string ,ASpell* >::iterator it = _spells.find(spell->getName());
	if (it != _spells.end())
		return;
	
	_spells.insert(std::make_pair(spell->getName(), spell->clone()));
}

void Warlock::forgetSpell(std::string spell)
{
	std::map<std::string ,ASpell* >::iterator it = _spells.find(spell);
	if (it == _spells.end())
		return;
	
	delete it->second;
	_spells.erase(spell);
}

void Warlock::launchSpell(std::string spell, ATarget& target)
{
	std::map<std::string ,ASpell* >::iterator it = _spells.find(spell);
	if (it == _spells.end())
		return;

	it->second->launch(target);
}

void Warlock::introduce() const
{
	std::cout << _name << ": I am "<< _name << ", " << _title << "!"<< std::endl;
}

Warlock::Warlock(std::string name, std::string title) :_name(name), _title(title)
{
	std::cout << _name << ": This looks like another boring day." << std::endl;
}

Warlock::~Warlock()
{
	std::cout << _name << ": My job here is done!" << std::endl;
}