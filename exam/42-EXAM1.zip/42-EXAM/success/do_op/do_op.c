#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

int    operation(int n1, char *sinal, int n2)
{
    if (sinal[0] == '+' )
        return (printf("%d\n", (n1 + n2)));

    else if (sinal[0] == '-' )
        return (printf("%d\n", (n1 - n2)));

    else if (sinal[0] == '*' )
        return (printf("%d\n", (n1 * n2)));
    
    else if (sinal[0] == '/' )
        return (printf("%d\n", (n1 / n2)));
    
    else if (sinal[0] == '%' )
        return (printf("%d\n", (n1 % n2)));
    
}


int main(int argc, char **argv)
{
    
    if (argc == 4)
        operation(atoi(argv[1]), argv[2], atoi(argv[3]));
    else
        write(1,"\n",1);
}