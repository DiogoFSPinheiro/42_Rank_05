
#include <stdio.h>
#include <unistd.h>
#include <stdarg.h>
#include <stdio.h>


int	ft_putchar(char c)
{
	write(1, &c, 1);

	return (1);
}

int	ft_putstr(char *str)
{
	int c;

	c = 0;
	if (!str)
		return (write(1,"(null)",6));

	while(*str)
	{
		c += ft_putchar(*str);
		str++;
	}
	return (c);
}

int	ft_putnbr_hexa(unsigned int i, int count)
{
	char *base;

	base = "0123456789abcdef";
	if (i >= 16)
	{
		count = ft_putnbr_hexa(i / 16, count);
		i = i % 16;
	}
	if (i < 16)
		count += ft_putchar(base[i]);

	return (count);
}

int	ft_putnbr(int i, int count)
{
	if (i == -2147483648)
	{
		write(1,"-2147483648",11);
		count = 11;
	}
	else
	{
		if (i < 0)
		{
			count += ft_putchar('-');
			i = -i;
		}
		while (i > 9)
		{
			count = ft_putnbr(i / 10, count);
			i = i % 10;
		}
		if (i < 10)
			count += ft_putchar(i + 48);
	}
	return (count);
}

int	ft_get_format(char type, va_list args)
{
	if (type == 'c')
		return (ft_putchar(va_arg(args, int)));
	else if (type == 's')
		return (ft_putstr(va_arg(args, char *)));
	else if (type == 'd')
		return (ft_putnbr(va_arg(args, int), 0));
	else if (type == 'x')
		return (ft_putnbr_hexa(va_arg(args, int), 0));
	return (0);
}

int ft_printf(const char *format, ... )
{
	va_list args;
	int		len;

	len = 0;
	va_start(args, format);
	while(*format)
	{
		if (*format == '%')
			len += ft_get_format(*(++format), args);
		else
			len += write( 1, format, 1);
		format++;
	}
	return (len);

}
/*
int	main()
{
	int i = 0;
	int	c = 0;

	//i = ft_printf("Magic %s is %d\n", "number", 42);
	//c = printf("Magic %s is %d\n", "number", 42);

	i += ft_printf("%x\n", -12);
	c += printf("%x\n", -12);

	ft_printf("my:  %x\n", i);
	printf("pritf: %x\n", c);
}
*/