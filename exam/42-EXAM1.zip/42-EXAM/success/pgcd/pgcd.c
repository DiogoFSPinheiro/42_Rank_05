#include <stdlib.h>
#include <unistd.h>
#include <stdbool.h>
#include <stdio.h>

void    put_char(char c)
{
    write(1,&c,1);
}



void    pgcd(int n1, int n2)
{
    if (n1 > 0 && n2 >0 )
    {
        while(n1 != n2)
        {
            if (n1 > n2)
                n1 = n1 - n2;
            else
                n2 = n2 - n1;
        }
        printf("%d\n", n1);

    }
}




int main(int c, char **v)
{
    if (c == 3)
    {
        pgcd(atoi(v[1]), atoi(v[2]));
    }
    else
        write(1,"\n",1);
}