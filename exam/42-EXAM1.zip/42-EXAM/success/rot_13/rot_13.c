#include <stdlib.h>
#include <unistd.h>

void    rot(char *str)
{
    int c = 0;
    
    while(str[c])
    {
        if ((str[c] >= 'a' && str[c] <= 'z'))
            str[c] = ((str[c] - 'a' + 13) % 26 ) + 'a';
        if ((str[c] >= 'A' && str[c] <= 'Z'))
            str[c] = ((str[c] - 'A'+ 13) % 26 ) + 'A';
        write(1, &str[c], 1);
        c++;
    }
    write(1,"\n",1);
}




int main(int argc, char **argv)
{
    if (argc == 2)
        rot(argv[1]);
    else
        write(1,"\n",1);
}