#include <stdlib.h>
#include <unistd.h>
#include <stdbool.h>

void    put_char(char c)
{
    write(1,&c,1);
}

void    ft_doubles(char *str1, char *str2)
{
    int c = 0;
    int i = 0;
    bool printed[250] = {false};

    while (str1[c])
    {
        i = 0;

        while (str2[i])
        {
            if (str1[c] == str2[i] && !printed[str1[c]])
            {
                put_char(str1[c]);
                printed[str1[c]] = true;
                i++;
                break;
            }
            i++;
        }
        c++;
    }
}




int main(int c, char **v)
{
    if (c == 3)
    {
        ft_doubles(v[1], v[2]);
        write(1,"\n",1);
    }
    else
        write(1,"\n",1);
}