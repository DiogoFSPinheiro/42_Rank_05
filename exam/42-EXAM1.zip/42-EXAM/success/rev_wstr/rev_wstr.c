#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

int ft_strlen(char *str)
{
    int c = 0;

    while (str[c])
        c++;
    return c;
}

void operation(char *str)
{
    int c = 0;
    int i;

    c = ft_strlen(str) - 1;
    i = c;

    while (c >= 0)
    {
        if (str[c] == ' ')
        {
            i = c;
            c++;
            while (str[c] != '\0' && str[c] != ' ' )
            {
                write(1, &str[c], 1);
                c++;
            }
            write(1, " ", 1);
            c = i;

        }
        if (c == 0)
        {
            while (str[c] != '\0' && str[c] != ' ' )
            {
                write(1, &str[c], 1);
                c++;
            }
            write(1, "\n", 1);
            c = 0;
        }
        c--;
    }
}




int main(int argc, char **argv)
{
    if (argc == 2)
        operation(argv[1]);
    else
        write(1,"\n",1);
}