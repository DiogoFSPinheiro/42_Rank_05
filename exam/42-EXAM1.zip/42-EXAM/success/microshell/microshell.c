#include <string.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>

void error(char *str)
{
    while(*str)
        write(2,str++,1);
}

void    set_pipe(int has_pipe, int *fd, int end)
{
    if (has_pipe && (dup2(fd[end],end) == -1 || close(fd[0]) == -1 || close(fd[1]) == -1))
        error("error: fatal\n"), exit(1);
}

int     cd(char **argv, int c)
{
    if (c != 2)
        return error("error: cd: bad arguments\n"), 1;
    if (chdir(argv[1]) == -1)
        return error("error: cd: cannot change directory to "), error(argv[1]), error("\n"), 1;
    return 0;
}

int     exec(char **argv, int c, char **env)
{
    int has_pipe, pid, fd[2], status;

    has_pipe = argv[c] && !strcmp(argv[c], "|");

    if (!has_pipe && !strcmp(*argv, "cd"))
        return cd(argv, c);
    if (has_pipe && pipe(fd) == -1)
        error("error: fatal\n"), exit(1);
    if ((pid = fork()) == -1)
        error("error: fatal\n"), exit(1);
    if (!pid)
    {
        argv[c] = 0;
        set_pipe(has_pipe, fd, 1);
        if (!strcmp(*argv, "cd"))
            exit(cd(argv, c));
        execve(*argv, argv, env);
        error("error: cannot execute "), error(*argv), error("\n"), exit(1);
    }
    waitpid(pid, &status, 0);
    set_pipe(has_pipe, fd, 0);
    return WIFEXITED(status) && WEXITSTATUS(status);

}

int main(int cnt, char **argv, char **env)
{
    int c = 0, status = 0;

    (void)cnt;
    while(argv[c])
    {
        argv += c + 1;
        c = 0;

        while(argv[c] && strcmp(argv[c], "|") && strcmp(argv[c], ";"))
            c++;

        if(c)
            status = exec(argv, c, env);

    }
    return status;

}