#include <unistd.h>

void    ft_putchar(char c)
{
    write(1, &c ,1);
}
int ft_len(char *str)
{
    int c;

    c = 0;
    while(str[c])
        c++;
    return c;
}
void    ft_lastword(char *str)
{
    int c;
    int i;
    
    c = ft_len(str) - 1;
    

    while (str[c] == ' ' || str[c] == '\t' || str[c] == '\n')
        c--;

    i = c;
    while (str[c] != ' ' && str[c] != '\t' && str[c] != '\n' && str[c] != '\0')
    {
        c--;
    }
    c++;
    while(i - c >= 0)
    {
        
        ft_putchar(str[c]);
        c++;
    }
    write(1,"\n",1);
}

int main(int argc, char **argv)
{
    if (argc == 2)
    {
        ft_lastword(argv[1]);
    }
    else
        write(1,"\n",1);
}