#include <unistd.h>

void    ft_putchar(char c)
{
    write(1, &c ,1);
}
int ft_len(char *str)
{
    int c;

    c = 0;
    while(str[c])
        c++;
    return c;
}
void    ft_lastword(char *str)
{
    int c;
    int i;

    c = 0;
    i = 0;
    while (str[c])
    {
        if (str[c] >= 'A' && str[c] <= 'Z')
        {
            str[c] += 32;
        }
        if ((str[c] >= 'a' && str[c] <= 'z') && (str[c+1] == ' ' || str[c+1] == '\t' || str[c+1] == '\n' || str[c+1] == '\0'))
        {
            str[c] -= 32;
        }
        ft_putchar(str[c]);
        c++;

    }
    write(1,"\n",1);
}



int main(int argc, char **argv)
{
    int c;

    c = 1;
    if (argc >= 2)
    {
        while (argv[c])
        {
            ft_lastword(argv[c]);
            c++;
        }
    }
    else
        write(1,"\n",1);
}