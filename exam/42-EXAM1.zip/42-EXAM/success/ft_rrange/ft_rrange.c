#include <unistd.h>
#include <stdlib.h>

void    ft_putchar(char c)
{
    write(1, &c, 1);
}

void    putnbr(int n)
{
    if (n > 9)
    {
        putnbr(n / 10);
        putnbr(n % 10);
    }
    else
    {
        ft_putchar(n + 48);
    }
}

int len(int *str)
{
    int c = 0;
    while(str[c])
        c++;
    return c;
}

int     *ft_rrange(int start, int end)
{
    int total = end - start;
    int *array;
    int c = 1;
    int atual = 1;

    array = malloc(sizeof(int) * total);
    if (!array)
        return (NULL);
    array[0] = end;
    //putnbr(array[0]);
    //write(1, "\n", 1);
    while (total >= c)
    {
        array[c] = end - atual;
        //putnbr(end - atual);
        //write(1, "\n", 1);
        atual++;
        c++;
    }
    return (array);
}
/*
int main(void)
{
    int     *array;
    array = ft_rrange(1, 3);
}
*/
