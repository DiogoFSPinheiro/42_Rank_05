#include <unistd.h>
#include <stdlib.h>

int len(char *str)
{
    int c = 0;
    while(str[c])
        c++;
    return c;
}

char    *ft_strdup(char *src)
{
    int     size = len(src);
    char    *dup;
    int     c = 0;

    dup = malloc(sizeof(char) * (size + 1));
    if (!dup)
        return NULL;

    while (src[c])
    {
        dup[c] = src[c];
        c++;
    }
    dup[c] = '\0';

     return (dup);
}
/*
void main(void)
{
    char *d;

    d = ft_strdup("ola");
    write(1, d, len(d));
}
*/