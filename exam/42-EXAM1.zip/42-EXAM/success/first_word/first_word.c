#include <unistd.h>

void    ft_putchar(char c)
{
    write(1, &c ,1);
}

void    ft_firstword(char *str)
{
    int c;

    c = 0;
    while (str[c] == ' ' || str[c] == '\t' || str[c] == '\n')
        c++;

    while (str[c] != ' ' && str[c] != '\t' && str[c] != '\n' && str[c] != '\0')
    {
        ft_putchar(str[c]);
        c++;
    }
    write(1,"\n",1);
}

int main(int argc, char **argv)
{
    if (argc == 2)
    {
        ft_firstword(argv[1]);
    }
    else
        write(1,"\n",1);
}