#include <unistd.h>
#include <stdlib.h>

void	ft_putstr(char *str)
{
	int	c;

	c = 0;
	while (str[c])
	{
		write(1, &str[c], 1);
		c++;
	}
}

int	*unit(char *str1, char *str2)
{
	char	*mixed;
	int		c;
	int		i;
	int		mixedindex = 0;
	int		len1 = 0;

	while (str1[len1])
		len1++;
	
	c = 0;
	while (str1[c])
	{
		i = 0;
		while (str2[i])
		{
			if (str1[c] == str2[i])
			{
				mixed[mixedindex++] = str1[c];
				break;
			}
			i++;
		}
		c++;
	}
	ft_putstr(mixed);
	write(1, "\n", 1);
}

int	main(int argc, char** argv)
{

	if (argc == 3)
		unit(argv[1], argv[2]);
	else
		write(1, "\n", 1);
}