#include <stdlib.h>
#include <unistd.h>
#include <stdbool.h>
#include <stdio.h>

void    put_char(char c)
{
    write(1,&c,1);
}



void    rosting(char *str)
{
    int c = 0;
    int i = 0;
    int s = 0;

    bool    print = false;
    while (str[c] == '\t' || str[c] == ' ')
        c++;
    s = c;
    while (str[c] != '\t' && str[c] != ' ' && str[c] != '\0')
        c++;
    i = c;
    while (str[c])
    {
        if (str[c] == '\t' || str[c] == ' ')
            c++;
        else
        {
            put_char(str[c]);
            if ((str[c+1] == '\t' || str[c+1] == ' ') && str[c+1] != '\0')
                put_char(' ');
            print = true;
            c++;
        }
    }
    if(print && str[c-1] != ' ')
        write(1," ",1);
    while (i > s)
    {
        put_char(str[s]);
        s++;
    }
    
}




int main(int c, char **v)
{

    rosting(v[1]);
    write(1,"\n",1);

}