#include <unistd.h>

void    ft_putchar(char c)
{
    write(1, &c, 1);
}

void    putnbr(int n)
{
    if (n > 9)
    {
        putnbr(n / 10);
        putnbr(n % 10);
    }
    else
    {
        ft_putchar(n + 48);
    }
}


int main(void)
{
    int c = 1;

    while (c <=100)
    {
        if (c % 3 == 0 && c % 5 == 0)
            write(1, "fizzbuzz\n",9);
        else if (c % 3 == 0)
            write(1, "fizz\n",5);
        else if (c % 5 == 0)
            write(1, "buzz\n",5);
        else
        {
            putnbr(c);
            write(1, "\n",1);
        }
        c++;
    }
    
}