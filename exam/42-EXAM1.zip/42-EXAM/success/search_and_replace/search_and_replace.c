#include <unistd.h>

int ft_strlen(char *str)
{
    int c;

    while (str[c])
        c++;
    return c;
}


void    replace(char *str, char *l, char *s)
{
    int c = 0;
   
    while (str[c])
    {
        if (str[c] == l[0])
            str[c] = s[0];
        c++;
    }
    write(1, str, c);
    write(1,"\n",1);
}


int main(int argc, char **argv)
{
    
    if (argc == 4 && ft_strlen(argv[2]) == 1 && ft_strlen(argv[3]) == 1)
        replace(argv[1], argv[2], argv[3]);
    else
        write(1,"\n",1);
}