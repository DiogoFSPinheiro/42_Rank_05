#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

void    prime(int n)
{
    int c;
    c = 1;

    if (n == 1)
        printf("1");
    while(n >= ++c)
    {
        if(n % c == 0)
        {
            printf("%d", c);
            if (n == c)
                break;
            printf("*");
            n /= c;
            c = 1;
        }
    }
}

int main(int argc, char **argv)
{
    if (argc == 2)
    {
        int n = atoi(argv[1]);
        prime(n);
        printf("\n");
    }
    else
        printf("\n");
}